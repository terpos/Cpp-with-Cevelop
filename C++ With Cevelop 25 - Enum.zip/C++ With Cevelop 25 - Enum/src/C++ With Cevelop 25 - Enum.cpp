//============================================================================
// Name        : C++.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

enum {EARTH, WATER, WIND, FIRE};

int main() {
	string element[] = {"Earth", "Water", "Wind", "Fire"};
	int elementnum = 0;

	switch (elementnum )
	{
	case EARTH:
		cout << element[EARTH] << endl;
		break;
	case WATER:
		cout << element[WATER] << endl;
		break;
	case WIND:
		cout << element[WIND] << endl;
		break;
	case FIRE:
		cout << element[FIRE] << endl;
		break;
	}

	return 0;
}

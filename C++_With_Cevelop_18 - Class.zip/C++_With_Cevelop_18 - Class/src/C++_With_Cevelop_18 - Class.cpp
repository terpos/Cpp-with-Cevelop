#include<iostream>

using namespace std;

class tut{
public:
	tut();
	~tut();
	void printsomething();
private:

};

tut::tut()
{
	//uncomment below to use the constructor
	//cout << "I am a constructor" << endl;
};

tut::~tut()
{
	cout << "I am a destructor" << endl;
}

void tut::printsomething()
{
	cout << "stuff" << endl;
}

int main(){
	tut t;
	//uncomment down below to use the class function
	//t.printsomething();
	cout << "daklfj;dklfja;" << endl;
	return 0;
}


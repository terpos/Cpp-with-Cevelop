#include<iostream>
#include "tut.h"
#include "folder/tutinfolder.h"
//make sure that different_dir folder is in the C drive or else
//it will not work
#include "C:\different_dir\tut_dir.h"

using namespace std;

int main(){
	dirfunction();
	return 0;
}


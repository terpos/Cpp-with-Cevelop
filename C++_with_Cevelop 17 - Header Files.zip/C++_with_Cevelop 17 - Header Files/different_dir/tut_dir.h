#include <iostream>

using namespace std;

void dirfunction()
{
	cout << "bla bla bla dir" << endl;
}
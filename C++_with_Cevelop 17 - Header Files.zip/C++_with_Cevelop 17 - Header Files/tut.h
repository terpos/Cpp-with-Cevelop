#ifndef TUT_H_
#define TUT_H_


#include <iostream>

using namespace std;

void function()
{
	cout << "bla bla bla" << endl;
}


#endif /* TUT_H_ */

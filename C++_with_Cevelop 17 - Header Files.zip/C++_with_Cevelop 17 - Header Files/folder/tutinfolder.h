#ifndef FOLDER_TUTINFOLDER_H_
#define FOLDER_TUTINFOLDER_H_

#include <iostream>

using namespace std;

void folderfunction()
{
	cout << "bla bla bla folder" << endl;
}



#endif /* FOLDER_TUTINFOLDER_H_ */

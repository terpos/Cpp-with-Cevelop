#include<iostream>
#include <vector>

using namespace std;

int main(){
	vector <string> enemies;
	enemies.push_back("Lavos");
	enemies.push_back("Queen Zeal");
	enemies.push_back("Ozzie");
	
	//for loop
	for (int j = 0; j < enemies.size(); j++)
	{
		cout << enemies[j] << endl;
	}
	
	//for each
	for(string i : enemies)
	{
		cout << i << endl;
	}

	return 0;
}


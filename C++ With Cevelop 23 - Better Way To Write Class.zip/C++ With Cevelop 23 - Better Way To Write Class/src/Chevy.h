#include "car.h"

#ifndef CHEVY_H_
#define CHEVY_H_

class Chevy: public car{
public:
	Chevy();
	~Chevy();
};

#endif /* CHEVY_H_ */

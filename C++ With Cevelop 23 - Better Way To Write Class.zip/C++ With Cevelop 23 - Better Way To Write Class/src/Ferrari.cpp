#include "Ferrari.h"

Ferrari::Ferrari() {
	// TODO Auto-generated constructor stub
	setColor("Red");
	setMake("Ferrari");
	setModel("Enzo");
	setMaxSpeed(200);
}

Ferrari::~Ferrari() {
	// TODO Auto-generated destructor stub
}


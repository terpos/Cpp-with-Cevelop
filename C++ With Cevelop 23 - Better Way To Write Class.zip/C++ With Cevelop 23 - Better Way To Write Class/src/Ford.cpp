#include "Ford.h"

Ford::Ford() {
	setColor("Blue");
	setMake("Ford");
	setModel("Edge");
	setMaxSpeed(140);
}

Ford::~Ford() {
	// TODO Auto-generated destructor stub
}


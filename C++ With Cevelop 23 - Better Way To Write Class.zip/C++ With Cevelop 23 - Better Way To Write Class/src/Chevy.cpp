#include "Chevy.h"

Chevy::Chevy() {
		setColor("Gray");
		setMake("Chevy");
		setModel("Equinox");
		setMaxSpeed(140);

}

Chevy::~Chevy() {
	// TODO Auto-generated destructor stub
}


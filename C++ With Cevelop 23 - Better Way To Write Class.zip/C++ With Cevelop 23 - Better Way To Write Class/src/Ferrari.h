#include "car.h"

#ifndef FERRARI_H_
#define FERRARI_H_

class Ferrari : public car{
public:
	Ferrari();
	~Ferrari();
};

#endif /* FERRARI_H_ */

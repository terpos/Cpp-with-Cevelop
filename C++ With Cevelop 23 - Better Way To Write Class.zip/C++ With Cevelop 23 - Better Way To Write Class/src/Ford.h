#include "car.h"

#ifndef FORD_H_
#define FORD_H_

class Ford: public car {
public:
	Ford();
	~Ford();
};

#endif /* FORD_H_ */

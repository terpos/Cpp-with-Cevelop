//============================================================================
// Name        : C++.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <vector>

using namespace std;

int main() {

	//assigning datatype to a name
	typedef vector<int> intarray;

	//declaring a variable using the typedef name
	intarray x;

	//assigning the variables
	x.push_back(3);
	x.push_back(1);
	x.push_back(100);

	//outputting variables
	for (int i = 0; i < x.size(); i++)
	{
		cout << x[i] << endl;
	}

	return 0;
}
